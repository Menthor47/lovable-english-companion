import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";
import { z } from "npm:zod@3.25.76";

type LeadSource = "contact" | "audit";

const PHONE_ALLOWED_REGEX = /^[0-9+()\-.\s]+$/;

function isValidPhone(value: string): boolean {
    if (value.length < 7 || value.length > 50) return false;
    if (!PHONE_ALLOWED_REGEX.test(value)) return false;
    const digitCount = (value.match(/\d/g) ?? []).length;
    return digitCount >= 7;
}

const leadSchema = z.object({
    email: z.preprocess(
        (value: unknown) => (typeof value === "string" ? value.trim() : value),
        z.string().email(),
    ),
    phone: z.preprocess(
        (value: unknown) => {
            if (typeof value !== "string") return value;
            const trimmed = value.trim();
            if (!trimmed.length) return undefined;
            return trimmed;
        },
        z
            .string()
            .max(50)
            .refine((value: string) => isValidPhone(value), "Invalid phone")
            .optional(),
    ),
    website: z.preprocess(
        (value: unknown) => {
            if (typeof value !== "string") return value;
            const trimmed = value.trim();
            if (!trimmed.length) return undefined;
            if (/^https?:\/\//i.test(trimmed)) return trimmed;
            return `https://${trimmed}`;
        },
        z.string().url().optional(),
    ),
    message: z.preprocess(
        (value: unknown) => (typeof value === "string" ? value.trim() : value),
        z.string().max(5000).optional(),
    ),
    source: z.union([z.literal("contact"), z.literal("audit")]).optional(),
    website2: z.string().max(200).optional(),
});

type LeadPayload = z.infer<typeof leadSchema>;

type RateLimitState = { count: number; resetAt: number };

const rateLimitStore: Map<string, RateLimitState> = new Map();

const HTML_ESCAPE_MAP: Record<string, string> = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
};

function jsonResponse(body: Record<string, unknown>, init?: ResponseInit): Response {
    const headers = new Headers(init?.headers);
    headers.set("content-type", "application/json; charset=utf-8");
    return new Response(JSON.stringify(body), { ...init, headers });
}

function getStringEnv(name: string): string | null {
    const value = Deno.env.get(name);
    if (typeof value !== "string") return null;
    const trimmed = value.trim();
    return trimmed.length ? trimmed : null;
}

function getIntEnv(name: string, fallback: number): number {
    const raw = getStringEnv(name);
    if (!raw) return fallback;
    const parsed = Number(raw);
    if (!Number.isFinite(parsed)) return fallback;
    const intValue = Math.floor(parsed);
    return intValue > 0 ? intValue : fallback;
}

function getClientIp(request: Request): string {
    const forwardedFor = request.headers.get("x-forwarded-for");
    if (forwardedFor) {
        const first = forwardedFor.split(",")[0];
        if (typeof first === "string" && first.trim().length) return first.trim();
    }

    const realIp = request.headers.get("x-real-ip");
    if (realIp && realIp.trim().length) return realIp.trim();

    return "unknown";
}

function getRequestOrigin(request: Request): string | null {
    const origin = request.headers.get("origin");
    if (origin && origin.trim().length) return origin.trim();

    const referer = request.headers.get("referer");
    if (!referer) return null;
    try {
        return new URL(referer).origin;
    } catch {
        return null;
    }
}

function parseCsv(value: string): string[] {
    return value
        .split(",")
        .map((item) => item.trim())
        .filter((item) => item.length);
}

function isOriginAllowed(origin: string, allowedOrigins: string[]): boolean {
    return allowedOrigins.some((allowed) => allowed === origin);
}

function getCorsDecision(request: Request): {
    requestOrigin: string | null;
    allowedOrigins: string[] | null;
    allowedOrigin: string | null;
} {
    const requestOrigin = getRequestOrigin(request);
    const allowedOriginsRaw = getStringEnv("ALLOWED_ORIGINS");
    if (!allowedOriginsRaw) {
        return { requestOrigin, allowedOrigins: null, allowedOrigin: null };
    }

    const allowedOrigins = parseCsv(allowedOriginsRaw);
    const allowedOrigin =
        requestOrigin && isOriginAllowed(requestOrigin, allowedOrigins) ? requestOrigin : null;

    return { requestOrigin, allowedOrigins, allowedOrigin };
}

function buildCorsHeaders(allowedOrigin: string | null): HeadersInit {
    if (!allowedOrigin) return {};
    return {
        "access-control-allow-origin": allowedOrigin,
        vary: "origin",
    };
}

function buildPreflightHeaders(allowedOrigin: string): HeadersInit {
    return {
        "access-control-allow-origin": allowedOrigin,
        "access-control-allow-methods": "POST, OPTIONS",
        "access-control-allow-headers": "content-type, authorization, apikey",
        "access-control-max-age": "86400",
        vary: "origin",
    };
}

function checkRateLimit(request: Request): { ok: true } | { ok: false; retryAfterSeconds: number } {
    const rateLimitMax = getIntEnv("CONTACT_RATE_LIMIT_MAX", 8);
    const rateLimitWindowSeconds = getIntEnv("CONTACT_RATE_LIMIT_WINDOW_SECONDS", 600);
    const now = Date.now();

    if (rateLimitStore.size > 1000) {
        for (const [key, entry] of rateLimitStore) {
            if (entry.resetAt <= now) rateLimitStore.delete(key);
        }
    }

    const ip = getClientIp(request);
    const existing = rateLimitStore.get(ip);

    if (!existing || existing.resetAt <= now) {
        rateLimitStore.set(ip, { count: 1, resetAt: now + rateLimitWindowSeconds * 1000 });
        return { ok: true };
    }

    if (existing.count >= rateLimitMax) {
        const retryAfterSeconds = Math.max(1, Math.ceil((existing.resetAt - now) / 1000));
        return { ok: false, retryAfterSeconds };
    }

    rateLimitStore.set(ip, { count: existing.count + 1, resetAt: existing.resetAt });
    return { ok: true };
}

function escapeHtml(value: string): string {
    return value.replace(/[&<>"']/g, (char) => HTML_ESCAPE_MAP[char] ?? char);
}

async function sendResendEmail(params: {
    apiKey: string;
    from: string;
    to: string;
    subject: string;
    html: string;
    replyTo?: string;
}): Promise<{ ok: true } | { ok: false; error: string }> {
    let response: Response;
    try {
        response = await fetch("https://api.resend.com/emails", {
            method: "POST",
            headers: {
                Authorization: `Bearer ${params.apiKey}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                from: params.from,
                to: [params.to],
                subject: params.subject,
                html: params.html,
                ...(params.replyTo ? { reply_to: params.replyTo } : {}),
            }),
        });
    } catch (error: unknown) {
        const message = error instanceof Error ? error.message : "Network error";
        return { ok: false, error: message };
    }

    if (response.ok) return { ok: true };

    const text = await response.text();
    return { ok: false, error: text || `Resend error: ${response.status}` };
}

function getSupabaseAdmin(): ReturnType<typeof createClient> | null {
    const supabaseUrl = getStringEnv("SUPABASE_URL");
    const serviceRoleKey = getStringEnv("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceRoleKey) return null;

    return createClient(supabaseUrl, serviceRoleKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false,
            detectSessionInUrl: false,
        },
    });
}

async function storeSubmission(params: {
    email: string;
    website?: string;
    phone?: string;
}): Promise<{ ok: true } | { ok: false; error: string }> {
    const supabaseAdmin = getSupabaseAdmin();
    if (!supabaseAdmin) {
        return { ok: false, error: "Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY" };
    }

    const baseRow: Record<string, unknown> = {
        email: params.email,
        website: params.website ?? null,
    };

    const tryWithPhone: Record<string, unknown> = {
        ...baseRow,
        phone: params.phone ?? null,
    };

    const { error: firstError } = await supabaseAdmin
        .from("contact_submissions")
        .insert([tryWithPhone]);

    if (!firstError) return { ok: true };

    const message = firstError.message ?? "Insert failed";
    const phoneColumnMissing =
        message.toLowerCase().includes("phone") &&
        (message.toLowerCase().includes("schema cache") ||
            message.toLowerCase().includes("column") ||
            message.toLowerCase().includes("does not exist"));

    if (!phoneColumnMissing) {
        return { ok: false, error: message };
    }

    const { error: secondError } = await supabaseAdmin
        .from("contact_submissions")
        .insert([baseRow]);

    if (secondError) {
        return { ok: false, error: secondError.message ?? "Insert failed" };
    }

    return { ok: true };
}

Deno.serve(async (request: Request): Promise<Response> => {
    const { requestOrigin, allowedOrigins, allowedOrigin } = getCorsDecision(request);
    const corsHeaders = buildCorsHeaders(allowedOrigin);

    if (request.method === "OPTIONS") {
        if (!allowedOrigins) return new Response(null, { status: 204 });
        if (!allowedOrigin) return new Response(null, { status: 403 });
        return new Response(null, { status: 204, headers: buildPreflightHeaders(allowedOrigin) });
    }

    if (request.method !== "POST") {
        return jsonResponse(
            { success: false, error: "Method not allowed" },
            { status: 405, headers: corsHeaders },
        );
    }

    if (allowedOrigins && !allowedOrigin) {
        return jsonResponse({ success: false, error: "Forbidden" }, { status: 403, headers: corsHeaders });
    }

    const rateLimit = checkRateLimit(request);
    if (!rateLimit.ok) {
        const headers = new Headers(corsHeaders);
        headers.set("retry-after", String(rateLimit.retryAfterSeconds));
        return jsonResponse({ success: false, error: "Too many requests" }, { status: 429, headers });
    }

    let raw: unknown;
    try {
        raw = await request.json();
    } catch {
        return jsonResponse({ success: false, error: "Invalid JSON" }, { status: 400, headers: corsHeaders });
    }

    const parsed = leadSchema.safeParse(raw);
    if (!parsed.success) {
        return jsonResponse({ success: false, error: "Invalid payload" }, { status: 400, headers: corsHeaders });
    }

    const payload: LeadPayload = parsed.data;
    const source: LeadSource = payload.source ?? "contact";

    if (payload.website2?.trim().length) {
        return jsonResponse({ success: true }, { headers: corsHeaders });
    }

    const stored = await storeSubmission({
        email: payload.email,
        website: payload.website,
        phone: payload.phone,
    });

    if (!stored.ok) {
        console.error("Supabase insert failed:", stored.error);
        return jsonResponse(
            { success: false, error: "Failed to store submission." },
            { status: 502, headers: corsHeaders },
        );
    }

    const resendApiKey = getStringEnv("RESEND_API_KEY");
    const resendFromEmail = getStringEnv("RESEND_FROM_EMAIL");
    const leadsToEmail = getStringEnv("LEADS_TO_EMAIL");

    if (!resendApiKey || !resendFromEmail || !leadsToEmail) {
        return jsonResponse(
            { success: false, error: "Server is not configured for lead capture yet." },
            { status: 500, headers: corsHeaders },
        );
    }

    const userAgent = request.headers.get("user-agent") ?? "";
    const referer = request.headers.get("referer") ?? "";

    const subject =
        source === "audit"
            ? `New AI Audit Request — ${payload.website ?? "No website provided"}`
            : `New Contact Request — ${payload.website ?? "No website provided"}`;

    const websiteHtml = payload.website
        ? `<div><strong>Website:</strong> ${escapeHtml(payload.website)}</div>`
        : `<div><strong>Website:</strong> (none)</div>`;

    const phoneHtml = payload.phone
        ? `<div><strong>Phone:</strong> ${escapeHtml(payload.phone)}</div>`
        : `<div><strong>Phone:</strong> (none)</div>`;

    const messageHtml = payload.message
        ? `<div><strong>Message:</strong><br/>${escapeHtml(payload.message)}</div>`
        : "";

    const internalHtml = `
<div style="font-family: ui-sans-serif, system-ui; line-height: 1.6;">
  <h2 style="margin: 0 0 12px;">New lead</h2>
  <div><strong>Source:</strong> ${escapeHtml(source)}</div>
  <div><strong>Email:</strong> ${escapeHtml(payload.email)}</div>
  ${phoneHtml}
  ${websiteHtml}
  ${messageHtml}
  <div><strong>Origin:</strong> ${escapeHtml(requestOrigin ?? "")}</div>
  <div><strong>IP:</strong> ${escapeHtml(getClientIp(request))}</div>
  <div><strong>Referer:</strong> ${escapeHtml(referer)}</div>
  <div><strong>User-Agent:</strong> ${escapeHtml(userAgent)}</div>
</div>`;

    const internalSend = await sendResendEmail({
        apiKey: resendApiKey,
        from: resendFromEmail,
        to: leadsToEmail,
        subject,
        html: internalHtml,
        replyTo: payload.email,
    });

    if (!internalSend.ok) {
        console.error("Resend internal lead email failed:", internalSend.error);
        return jsonResponse(
            { success: false, error: "Lead capture failed. Please try again later." },
            { status: 502, headers: corsHeaders },
        );
    }

    const confirmationSubject =
        source === "audit"
            ? "We received your AI audit request — AGSEO"
            : "We received your message — AGSEO";

    const confirmationHtml =
        source === "audit"
            ? `
<div style="font-family: ui-sans-serif, system-ui; line-height: 1.6;">
  <p>Hi,</p>
  <p>
    Thanks — we received your AI SEO audit request${payload.website ? ` for <strong>${escapeHtml(payload.website)}</strong>` : ""}.
  </p>
  <p>You’ll receive a follow-up from our team after review.</p>
  <p>AGSEO</p>
</div>`
            : `
<div style="font-family: ui-sans-serif, system-ui; line-height: 1.6;">
  <p>Hi,</p>
  <p>
    Thanks — we received your message${payload.website ? ` regarding <strong>${escapeHtml(payload.website)}</strong>` : ""}.
  </p>
  <p>We’ll get back to you shortly.</p>
  <p>AGSEO</p>
</div>`;

    const confirmationSend = await sendResendEmail({
        apiKey: resendApiKey,
        from: resendFromEmail,
        to: payload.email,
        subject: confirmationSubject,
        html: confirmationHtml,
    });

    if (!confirmationSend.ok) {
        console.error("Resend confirmation email failed:", confirmationSend.error);
        return jsonResponse({ success: true, confirmationSent: false }, { headers: corsHeaders });
    }

    return jsonResponse({ success: true }, { headers: corsHeaders });
});
